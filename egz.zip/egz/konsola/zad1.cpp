#include <bits/stdc++.h>
using namespace std;
//**********************************
//nazwa: plec
//Opis: Funkcja zwraca płeć osoby, do której należy pesel
//parametry: tablica tab
//zwracane: zmienna t, która oznaczająca płeć 
//autor: 05262026206
//**************************
int plec(int tab[])
{
	int t;
	int p=tab[10];
	if(p%2==0)
	t=0;
	else if(p%2==1)
	t=1;
	return t;
}
int kontrolna(int tab[], int wagi[])
{
	int r=0,m=0;
	int suma=0;
	for(int i=0;i<=9;i++)
	{
		suma=suma+(wagi[i]*tab[i]);
	}
	m=suma%10;
	if(m==0)
	{
	r=m;
}
else {
	r=(10-m);
}
	return r;
}
main()
{
	int tab[11]={0,5,2,6,2,0,0,6,9,7,1};
	int wagi[10]={1,3,7,9,1,3,7,9,1,3};
	int pl=plec(tab);
	if(pl==0)
	{
		cout<<"kobieta"<<endl;
	}
	else {
		cout<<"mezczyzna"<<endl;
	}
	cout<<"kontrolna"<<endl;
	cout<<kontrolna(tab, wagi);
}
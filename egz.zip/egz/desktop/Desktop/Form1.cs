namespace Desktop
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            string nr = textBox1.Text;
            string nzw = nr + "-zdjecie.jpg";
            if (string.IsNullOrEmpty(nr))
            {
                MessageBox.Show("pusta warto�� jest nieprawid�owa", "alert");
            }
            else
            {
                pictureBox1.Load(nzw);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox3.Text != null && textBox2.Text!=null)
            {
                string imie=textBox2.Text;
                string nazw=textBox3.Text;
                string oczy="";
                //sprawdzenie zaznaczenia:
                if(radioButton1.Checked)
                {
                     oczy = "niebieskie";
                }
                else if(radioButton2.Checked)
                {
                     oczy = "zielone";
                }
                else if( radioButton3.Checked)
                {
                     oczy = "piwne";
                }

                if(imie!=null &&nazw!=null)
                {
                    MessageBox.Show(imie + " " + nazw +oczy);
                }
            }

        }
    }
}